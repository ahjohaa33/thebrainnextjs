/** @type {import('next').NextConfig} */
const nextConfig = {
  /* config options here */
  reactCompiler: true,
   allowedDevOrigins: ['192.168.0.116'],
     images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "ponnobd.com",
        pathname: "/**",
      },
    ],
  },
};



export default nextConfig;
